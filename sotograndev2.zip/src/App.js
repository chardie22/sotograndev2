import React from 'react'
import {BrowserRouter as Router, Routes, Route} from "react-router-dom";
import Home from "./screen/HomeScreen/SHome";
import About from "./screen/AboutScreen/SAbout";
import Contact from "./screen/ContactScreen/SContact";
import Facilities from "./screen/FacilitiesScreen/SFacilities";
import Gallery from "./screen/GalleryScreen/SGallery";
import Location from "./screen/LocationScreen/SLocation";

const App = () => {
  return (
    <Router>
          <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/facilities" element={<Facilities />} />
          <Route path="/gallery" element={<Gallery />} />
          <Route path="/location" element={<Location />} />
       </Routes>
    </Router>
  )
}

export default App