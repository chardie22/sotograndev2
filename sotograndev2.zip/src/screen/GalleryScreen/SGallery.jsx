import React from 'react';
import Navbar from '../../components/Navbar/Navbar';
import ImageGallery from "../../contexts/ImageGallery";
import "./sgallery.css";

const SGallery = () => {
  return (
    <>
    <Navbar/>
    <div className="s-gallerycover" />
    <div className='sgallery'>
    {
      ImageGallery.map ((item) => {
        return (
            <img className="sitem" src ={item} alt= "" />

        )
      })
    }
  </div>
  </>
  )
}

export default SGallery
