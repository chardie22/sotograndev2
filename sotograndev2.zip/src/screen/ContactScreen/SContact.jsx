import React from 'react'
import Navbar from "../../components/Navbar/Navbar"
import "./scontact.css";

const SContact = () => {
  return (
    <>
    <Navbar/>
    <div className="s-contactcover">
    </div>
   </>
  )
}

export default SContact
