import React from 'react'
import Navbar from '../../components/Navbar/Navbar';
import './sfacilities.css'

const SFacilities = () => {
  return (
    <>
    <Navbar/>
    <div className="s-facilitiescover"></div>
  </>
  )
}

export default SFacilities
