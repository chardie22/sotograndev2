import React from 'react'
import "./shome.css"
import Navbar from '../../components/Navbar/Navbar'
import HomeTextList from '../../contexts/HomeTextList'

const SHome = () => {
  return (
    <>
    <Navbar/>
    <div className="s-homecover">
    <h1 className='s-title'>Soto Grande, Katipunan</h1>
    <h2 className='ss-title'>Experience contemporary living at the heart of Katipunan Ave, Quezon City</h2>
    </div>





<div className='ss-main'>
<div className='st-wrapper'>
<span className='s-title'>Your Home at The Katipunan</span>
</div>
<div className='s-row'>
<p className='s-parags'>Relocating, in between residential arrangements, or looking for a luxurious haven for an extended staycation?<br/>
Discover your new home and live the vibe set in the spacious, contemporary, and well-appointed units of Soto Grande Residences at The<br/>Katipunan.</p>


<div className='s-col1'>
   <div className='s-left'>
      <span className='s-t1'>{HomeTextList.sub1}</span>
      <br/>
      <p className='s-p1'>Enjoy an elevated level of contemporary living and choose from our 97<br/>serviced residences of refined style, modern amenities<br/>and enviable city views.
      </p>   
   </div>
   <img src="https://i.ibb.co/h8z1MHJ/g1.webp" alt="" width="26%"/>
</div>



<div className='s-col2'>
   <div className='s-left'>
      <span className='s-t2'>{HomeTextList.sub2}</span>
      <br/>
      <p className='s-p1'>Dine and unwind with the ultimate La-Grande dining<br/>experience set in our innovative concept restaurants of rich varieties,<br/>authentic Cantonese cuisine, and vibrant South American flavours.<br/>Our team of culinary masters are dishing out the finest for your<br/>discerning palates.
      </p>   
   </div>
   <img src="https://i.ibb.co/pd25XTM/g2.jpg" alt="" width="26%"/>
</div>

</div>
</div>
   </>
   )
}

export default SHome