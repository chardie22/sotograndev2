import React from 'react'
import Navbar from '../../components/Navbar/Navbar'
import "./slocation.css"

const SLocation = () => {
  return (
    <>
    <Navbar/>
    <div className='s-location'>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3860.6996464091458!2d121.06842811527923!3d14.616178280612218!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397b7f2fec2c27b%3A0x5d1dd3aa1c81abb8!2sSotoGrande-%20Katipunan!5e0!3m2!1sen!2sph!4v1664870137503!5m2!1sen!2sph"  width="100%"
    height="400"
    frameborder="0"
    style={{ border: 0 }}
    allowfullscreen=""
    aria-hidden="false"
    tabindex="0"></iframe>

    <div className='s-title'>
    <span className='soto'>SotoGrande Katipunan Location, Quezon City, Philippines</span>
    </div>
  </div>
    </>
  )
}

export default SLocation
