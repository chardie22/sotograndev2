import React from 'react';
import Navbar from '../../components/Navbar/Navbar';
import './sabout.css'

const SAbout = () => {
  return (
    <>
    <Navbar/>
    <div className="s-aboutcover"></div>
  
  </>
  )
}

export default SAbout
