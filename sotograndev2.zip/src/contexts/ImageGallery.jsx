const ImageGallery = [
    "https://i.ibb.co/XkMQY5C/2.jpg",
    "https://i.ibb.co/tKTYc35/3.jpg",
    "https://i.ibb.co/CmRqss7/4.jpg",
    "https://i.ibb.co/qgyrkW3/5.jpg",
    "https://i.ibb.co/593ztz1/1.jpg",
    "https://i.ibb.co/2vFS7vN/6.jpg",
    "https://i.ibb.co/x6C2PLH/7.jpg",
    "https://i.ibb.co/nQHC0Gm/8.jpg",
    "https://i.ibb.co/Fm0tX3X/9.jpg",
    "https://i.ibb.co/d4TP6QW/10.jpg",
]


export default ImageGallery;