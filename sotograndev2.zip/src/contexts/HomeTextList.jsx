const HomeTextList = {

    sub: 'Your Home at The Katipunan',
    des: 'Relocating, in between residential arrangements, or looking for a luxurious haven for an extended staycation?',
    des1: 'Discover your new home and live the vibe set in the spacious, contemporary, and well-appointed units of Soto Grande Residences at The Katipunan,',
    sub1: 'Soto Grande Residences at The Katipunan',
    sub2: 'Exceptional Dining Experiences',
}



export default HomeTextList;